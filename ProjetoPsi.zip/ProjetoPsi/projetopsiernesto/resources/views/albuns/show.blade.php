<i>ID-{{$album->id_album}}</i><br>
<i>Titulo-{{$album->titulo}}</i><br>
<i>Data lançamento-{{$album->data_lancamento}}</i><br>
<i>Observacoes-{{$album->observacoes}}</i><br>
<br>

<h5><u>Musicas:</u></h5>

@foreach($album->musicas as $musica)
<i>{{$musica->titulo}}</i>
@endforeach



