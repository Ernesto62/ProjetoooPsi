@extends('layout')
@section('titulo-pagina')

@endsection
@section('header')

@endsection
@section('conteudo')
<ul>
@foreach($generos as $genero)
<h3>
<a href="{{route('generos.show', ['id'=>$genero->id_genero])}}">
{{$genero->designacao}}</a></h3>
@endforeach
<img  src="musica.gif" alt="some text" width=400 height=300 align="center">
</ul>
{{$generos->render()}}
</div>
@endsection
