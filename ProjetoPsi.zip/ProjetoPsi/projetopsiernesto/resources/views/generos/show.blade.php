
<i>ID Genero-{{$genero->id_genero}}</i><br>
<i>Designação-{{$genero->designacao}}</i><br>
<i>Observações-{{$genero->observacoes}}</i><br>
<br>
<h5><u>Musicas:</u></h5>

@foreach($genero->musicas as $musica)
<i >{{$musica->titulo}}</i>
@endforeach

