
<i>ID-{{$musico->id_musico}}</i><br>
<i>Nome-{{$musico->nome}}</i><br>
<i>Nacionalidade-{{$musico->nacionalidade}}</i><br>
<i >Data Nascimento-{{$musico->data_nascimento}}</i><br>
<br>

<h5>Musicas:</h5>

@foreach($musico->musicas as $musica)
<i>{{$musica->titulo}}</i>
@endforeach



