
<i>ID-{{$musica->id_musica}}</i><br>
<i>Titulo-{{$musica->titulo}}</i><br>
<i>ID Musico-{{$musica->id_musico}}</i><br>
<i>ID Genero-{{$musica->id_genero}}</i><br>

<br>
<h5>Musico:</h5>

@foreach($musica->musicos as $musico)
<i>{{$musico->nome}}</i>
@endforeach

                    
               


