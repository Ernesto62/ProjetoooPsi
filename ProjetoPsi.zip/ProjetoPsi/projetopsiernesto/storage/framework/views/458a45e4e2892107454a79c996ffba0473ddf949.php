
<?php $__env->startSection('titulo-pagina'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
<ul>
<?php $__currentLoopData = $albuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>
<a  href="<?php echo e(route('albuns.show', ['id'=>$album->id_album])); ?>">

<?php echo e($album->titulo); ?></a></h3>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<img  src="musica.gif" alt="some text" width=400 height=300 align="center">
</ul>
<?php echo e($albuns->render()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ProjetoPsi\projetopsiernesto\resources\views/albuns/index.blade.php ENDPATH**/ ?>