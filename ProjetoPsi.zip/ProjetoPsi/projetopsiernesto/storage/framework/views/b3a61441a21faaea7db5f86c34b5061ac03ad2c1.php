<ul>
<?php $__currentLoopData = $albuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>
<a  href="<?php echo e(route('albuns.show', ['id'=>$album->id_album])); ?>">
<?php echo e($album->titulo); ?></a></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($albuns->render()); ?>

<?php /**PATH C:\Users\anton\Desktop\projeto-psi-ernesto\resources\views/albuns/index.blade.php ENDPATH**/ ?>