<ul>
<?php $__currentLoopData = $musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>
<a  href="<?php echo e(route('musicos.show', ['id'=>$musico->id_musico])); ?>">
<?php echo e($musico->nome); ?></a></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($musicos->render()); ?>

</div>

<?php /**PATH C:\Users\anton\Desktop\projeto-psi-ernesto\resources\views/musicos/index.blade.php ENDPATH**/ ?>