<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Musico;


class MusicosController extends Controller
{
     
 public function index(){
 	$musicos = Musico::paginate(4);
   	return view('musicos.index', ['musicos'=>$musicos]);
}

public function show (Request $request){
	$idMusico=$request->id;
	$musico=Musico::where('id_musico', $idMusico)->with('musicas')->first();
	return view('musicos.show',  ['musico'=>$musico]);
}
}