<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Musica;


class MusicasController extends Controller
{
       public function index(){
 	$musicas = Musica::paginate(12);
   	return view('musicas.index', ['musicas'=>$musicas]);
}

public function show (Request $request){
	$idMusica=$request->id;
	$musica=Musica::where('id_musica',$idMusica)->with('musicos')->first();
	return view('musicas.show',  ['musica'=>$musica]);
}

}

